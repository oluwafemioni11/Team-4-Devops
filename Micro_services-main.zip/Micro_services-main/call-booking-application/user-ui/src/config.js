export const CONTACT_EMAIL = 'deekshithsn@gmail.com'
export const PAYMENT_NUMBER = '99xxx33xxx'

